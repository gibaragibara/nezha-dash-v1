var e=function(){if(typeof __webpack_nonce__<"u")return __webpack_nonce__};export{e as g};
