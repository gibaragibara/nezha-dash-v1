function e(t){return o(t[0])+o(t[1])}function o(t){return String.fromCodePoint(127397+t.toUpperCase().charCodeAt(0))}export{e as g};
